package crawler;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class Test2 {

	@Test
	public void test() {
		Search sc = new Search();
		assertEquals("E://web", sc.path);
		
		File f = new File(sc.path);
		
		if(!f.exists())
		
		fail("Not yet implemented");
		
	}
	
	@Test
	public void test1() {
		fail("Not yet implemented");
	}

}
