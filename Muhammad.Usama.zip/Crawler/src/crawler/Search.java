package crawler;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

public class Search {
	 public String path= "D:\\web";
    public static void main(String[] args) throws Exception {
    	
    	Search search = new Search();
    	
        File[] fileList = search.getFileList(search.path);
        
        System.out.println("Please Enter word to search");
        Scanner sc = new Scanner(System.in);
        String word = sc.nextLine();
       
        for(File file : fileList) {
            search.word(file,word);
        }
    }
    
   public void word (File file,String toSearch){
	   
	   try {
		List<String> lines = Files.readAllLines(Paths.get(file.getAbsolutePath()),StandardCharsets.UTF_8);
		for(String line: lines)
		{
			String[]arr=line.split(" ");
			for (String arrs: arr) {
				if(arrs.equalsIgnoreCase(toSearch))
				{
				System.out.println(toSearch +"::" + file.getAbsolutePath());
				}
				
				
			}
		}
		
		
	   } catch (IOException e) {
		e.printStackTrace();
	}
	
   }

   public File[] getFileList(String dirPath) {
        File dir = new File(dirPath);   

        File[] fileList = dir.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.endsWith(".txt");
            }
        });
        
        return fileList;
    }
}
